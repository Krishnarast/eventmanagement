package com.springboot.controller;

import com.springboot.model.Event;
import com.springboot.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api")
public class EventController {

    @Autowired
    private EventRepository eventRepository;

    @GetMapping("/events")
    public List<Event> getAll() {
        return eventRepository.findAll();
    }

    @GetMapping("/event/{id}")
    public Event getById(@PathVariable Long id) {
        return eventRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Event not found"));
    }

    @GetMapping("/events/upcoming")
    public List<Event> getUpcoming() {
        return eventRepository.findByDateAfter(LocalDate.now());
    }

    @PostMapping("/event")
    public Event create(@RequestBody Event event) {
        return eventRepository.save(event);
    }

    @PutMapping("/event/{id}")
    public Event update(@PathVariable Long id, @RequestBody Event newEvent) {
        Event event = eventRepository.findById(id).orElseThrow();
        event.setName(newEvent.getName());
        event.setDate(newEvent.getDate());
        event.setVenue(newEvent.getVenue());
        event.setDescription(newEvent.getDescription());
        return eventRepository.save(event);
    }

    @DeleteMapping("/event/{id}")
    public void delete(@PathVariable Long id) {
        eventRepository.deleteById(id);
    }
}
